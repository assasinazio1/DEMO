﻿using FurniPlus.Classes;
using FurniPlus.Models;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace FurniPlus.Pages
{
    /// <summary>
    /// Interaction logic for AddEditMaterial.xaml
    /// </summary>
    public partial class AddEditMaterial : Page
    {
        private readonly Material _editingMaterial;

        public AddEditMaterial(Material material = null)
        {
            InitializeComponent();

            TypeComboBox.ItemsSource = AppData.db.MaterialTypes.ToList();

            if (material != null)
            {
                _editingMaterial = material;
                LoadData(material);
            }
        }

        private void LoadData(Material editingMaterial)
        {
            TooltipTextBox.Text = $"Редактирование материал: {editingMaterial.Name}";
            NameTextBox.Text = editingMaterial.Name;
            TypeComboBox.SelectedItem = AppData.db.MaterialTypes.FirstOrDefault(x => x.Id == editingMaterial.MaterialTypeId);
            UnitPriceTextBox.Text = editingMaterial.UnitPrice.ToString("F2");
            StockQuantityTextBox.Text = editingMaterial.StockQuantity.ToString("F2");
            MinQuantityTextBox.Text = editingMaterial.MinQuantity.ToString("F2");
            PackQuantityTextBox.Text = editingMaterial.PackQuantity.ToString("F2");
            UnitTextBox.Text = editingMaterial.Unit;
        }

        private void SaveMaterialButton_Click(object sender, RoutedEventArgs e)
        {
            if (_editingMaterial != null)
            {
                FillMaterialFields(_editingMaterial);
            }
            else
            {
                var newCard = new Material();
                FillMaterialFields(newCard);
                AppData.db.Materials.Add(newCard);
            }

            AppData.db.SaveChanges();

            MessageBox.Show("Информация о материале сохранена!", "Успех!", MessageBoxButton.OK, MessageBoxImage.Information);

            NavigationService.GoBack();
        }

        private void DecimanInput(object sender, TextCompositionEventArgs e)
        {
            var textBox = sender as TextBox;

            string fullText = textBox.Text.Insert(textBox.SelectionStart, e.Text);

            e.Handled = !decimal.TryParse(fullText, out _);
        }

        private void FillMaterialFields(Material material)
        {
            material.Name = NameTextBox.Text.Trim();
            material.MaterialTypeId = (TypeComboBox.SelectedItem as MaterialType).Id;
            material.UnitPrice = decimal.Parse(UnitPriceTextBox.Text);
            material.StockQuantity = decimal.Parse(StockQuantityTextBox.Text);
            material.MinQuantity = decimal.Parse(MinQuantityTextBox.Text);
            material.PackQuantity = decimal.Parse(PackQuantityTextBox.Text);
            material.Unit = UnitTextBox.Text.Trim();
        }
    }
}
