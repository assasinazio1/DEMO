﻿using FurniPlus.Classes;
using System.Windows;
using System.Linq;
using System.Windows.Controls;
using FurniPlus.Models;

namespace FurniPlus.Pages
{
    /// <summary>
    /// Interaction logic for MaterialsPage.xaml
    /// </summary>
    public partial class MaterialsPage : Page
    {
        public MaterialsPage()
        {
            InitializeComponent();

            LoadData();
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            MaterialsList.ItemsSource = AppData.db.Materials
                .ToList()
                .Select(m => new MaterialWithQuantity
                {
                    Material = m,
                    RequiredQuantity = MaterialCalculator.CalculateRequiredMaterial(m.Id)
                })
            .ToList();
        }

        private void AddMaterialButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddEditMaterial());
        }

        private void EditMaterialButton_Click(object sender, RoutedEventArgs e)
        {
            var currentMaterial = MaterialsList.SelectedItem as MaterialWithQuantity;

            if (currentMaterial == null)
            {
                MessageBox.Show("Сначала выберите материал из списка.", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            NavigationService.Navigate(new AddEditMaterial(currentMaterial.Material));
        }

        private void MaterialsList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            EditMaterialButton.IsEnabled = MaterialsList.SelectedItem != null;
            ShowProductsButton.IsEnabled = MaterialsList.SelectedItem != null;
        }

        private void ShowProductsButton_Click(object sender, RoutedEventArgs e)
        {
            var currentMaterial = MaterialsList.SelectedItem as MaterialWithQuantity;

            if (currentMaterial == null)
            {
                MessageBox.Show("Сначала выберите материал из списка.", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            NavigationService.Navigate(new ProductsList(currentMaterial.Material));
        }
    }
}
