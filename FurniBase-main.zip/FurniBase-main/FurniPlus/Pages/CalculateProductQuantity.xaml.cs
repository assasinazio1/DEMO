﻿using FurniPlus.Classes;
using FurniPlus.Models;
using System.Windows.Controls;

namespace FurniPlus.Pages
{
    /// <summary>
    /// Interaction logic for CalculateProductQuantity.xaml
    /// </summary>
    public partial class CalculateProductQuantity : Page
    {
        private Product _product;
        private Material _material;

        public CalculateProductQuantity(Product product, Material material)
        {
            InitializeComponent();


            _product = product;
            _material = material;
            TooltipTextBox.Text = $"Расчёт количества продукции для: {product.Name}";
        }

        private void CalculateButton_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            ResultTextBox.Text = MaterialCalculator.CalculateProductQuantity(
                _product.Id,
                _material.Id,
                int.Parse(RawQuantityTextBox.Text),
                double.Parse(P1TextBox.Text),
                double.Parse(P2TextBox.Text)
            )
            .ToString();
        }

        private void IntInput(object sender, System.Windows.Input.TextCompositionEventArgs e)
        {
            e.Handled = !int.TryParse(e.Text, out _);
        }

        private void DecimalInput(object sender, System.Windows.Input.TextCompositionEventArgs e)
        {
            var textBox = sender as TextBox;

            string fullText = textBox.Text.Insert(textBox.SelectionStart, e.Text);

            e.Handled = !decimal.TryParse(fullText, out _);
        }
    }
}
