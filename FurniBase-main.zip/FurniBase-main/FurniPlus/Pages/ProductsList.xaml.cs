﻿using FurniPlus.Models;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace FurniPlus.Pages
{
    /// <summary>
    /// Interaction logic for ProductsList.xaml
    /// </summary>
    public partial class ProductsList : Page
    {
        public ProductsList(Material material)
        {
            InitializeComponent();

            TooltipTextBox.Text = material.Name;
            ProductsListDataGrid.ItemsSource = material.ProductMaterials.ToList();
        }

        private void CalculateProductQuantityButton_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            var product = ProductsListDataGrid.SelectedItem as ProductMaterial;

            if (product == null)
            {
                MessageBox.Show("Сначала выберите продукт из списка.", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            NavigationService.Navigate(new CalculateProductQuantity(product.Product, product.Material));
        }

        private void ProductsListDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            CalculateProductQuantityButton.IsEnabled = ProductsListDataGrid.SelectedItem != null;
        }
    }
}
