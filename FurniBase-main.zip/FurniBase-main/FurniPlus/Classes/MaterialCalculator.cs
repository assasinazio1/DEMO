﻿using System;
using System.Linq;

namespace FurniPlus.Classes
{
    public static class MaterialCalculator
    {
        public static double CalculateRequiredMaterial(int materialId)
        {
            var products = AppData.db.ProductMaterials.Where(x => x.MaterialId == materialId).ToList();

            decimal totalQuantity = 0;

            foreach (var product in products)
            {
                totalQuantity += product.RequiredQuantity * product.Material.PackQuantity;
            }

            return Math.Round((double)totalQuantity, 2);
        }

        public static int CalculateProductQuantity(int productId, int materialId, int rawMaterialQuantity, double p1, double p2)
        {
            var product = AppData.db.Products.FirstOrDefault(x => x.Id == productId);
            var material = AppData.db.Materials.FirstOrDefault(x => x.Id == materialId);

            if (product == null || material == null) return -1;
            if (p1 < 0 || p2 < 0 || rawMaterialQuantity < 0) return -1;

            var materialPerUnit = p1 * p2 * (double)product.ProductType.Coefficient;
            double availableMaterial = rawMaterialQuantity * (1 - (double)material.MaterialType.WastePecentage / 100.0);
            int productQuantity = (int)(availableMaterial / materialPerUnit);

            return productQuantity;
        }
    }
}
