﻿using FurniPlus.Models;

namespace FurniPlus.Classes
{
    public static class AppData
    {
        public static user69Entities db = new user69Entities();
    }
}
