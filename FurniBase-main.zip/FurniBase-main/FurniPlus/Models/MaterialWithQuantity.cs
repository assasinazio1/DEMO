﻿namespace FurniPlus.Models
{
    public class MaterialWithQuantity
    {
        public Material Material { get; set; }
        public double RequiredQuantity { get; set; }
    }

}
