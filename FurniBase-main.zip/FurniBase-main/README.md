# FurniBase

### Использовано:
- .NET Framework 4.7.2
- WPF
- EntityFramework
- SSMS
- ну и че та там еще наверна
